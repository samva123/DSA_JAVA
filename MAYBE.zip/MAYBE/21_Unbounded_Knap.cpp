#include <bits/stdc++.h>
using namespace std;

// ========== 1. Recursive + Memoization ==========
int knapsackUtil(vector<int>& wt, vector<int>& val, int ind, int W, vector<vector<int>>& dp) {
    if (ind == 0) {
        return (W / wt[0]) * val[0];
    }
    //for bounded
    // if (ind == 0) {
    //     if (wt[0] <= W)
    //         return val[0];
    //     else
    //         return 0;
    // }
    if (dp[ind][W] != -1)
        return dp[ind][W];

    int notTaken = knapsackUtil(wt, val, ind - 1, W, dp);
    int taken = INT_MIN;
    if (wt[ind] <= W)
        taken = val[ind] + knapsackUtil(wt, val, ind, W - wt[ind], dp);

    return dp[ind][W] = max(notTaken, taken);
}

int unboundedKnapsackMemo(int n, int W, vector<int>& val, vector<int>& wt) {
    vector<vector<int>> dp(n, vector<int>(W + 1, -1));
    return knapsackUtil(wt, val, n - 1, W, dp);
}

// ========== 2. Tabulation (Bottom-Up) ==========
int unboundedKnapsackTabu(int n, int W, vector<int>& val, vector<int>& wt) {
    vector<vector<int>> dp(n, vector<int>(W + 1, 0));

    for (int i = wt[0]; i <= W; i++) {
        dp[0][i] = (i / wt[0]) * val[0];
    }

    for (int ind = 1; ind < n; ind++) {
        for (int cap = 0; cap <= W; cap++) {
            int notTaken = dp[ind - 1][cap];
            int taken = INT_MIN;
            if (wt[ind] <= cap)
                taken = val[ind] + dp[ind][cap - wt[ind]];
            dp[ind][cap] = max(notTaken, taken);
        }
    }

    return dp[n - 1][W];
}

// ========== 3. Space Optimized ==========
int unboundedKnapsackSpaceOpt(int n, int W, vector<int>& val, vector<int>& wt) {
    vector<int> cur(W + 1, 0);

    for (int i = wt[0]; i <= W; i++) {
        cur[i] = (i / wt[0]) * val[0];
    }

    for (int ind = 1; ind < n; ind++) {
        for (int cap = 0; cap <= W; cap++) {
            int notTaken = cur[cap];
            int taken = INT_MIN;
            if (wt[ind] <= cap)
                taken = val[ind] + cur[cap - wt[ind]];
            cur[cap] = max(notTaken, taken);
        }
    }

    return cur[W];
}

// ========== Main Function ==========
int main() {
    vector<int> wt = {2, 4, 6};
    vector<int> val = {5, 11, 13};
    int W = 10;
    int n = wt.size();

    cout << "Memoization: The Maximum value the thief can steal is " << unboundedKnapsackMemo(n, W, val, wt) << endl;
    cout << "Tabulation:  The Maximum value the thief can steal is " << unboundedKnapsackTabu(n, W, val, wt) << endl;
    cout << "Space Opt:   The Maximum value the thief can steal is " << unboundedKnapsackSpaceOpt(n, W, val, wt) << endl;

    return 0;
}
